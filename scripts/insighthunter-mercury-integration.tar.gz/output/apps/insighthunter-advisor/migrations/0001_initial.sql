-- ih-advisor D1 schema
-- Run: wrangler d1 execute ih-advisor --file=migrations/0001_initial.sql

CREATE TABLE IF NOT EXISTS firms (
  id              TEXT PRIMARY KEY,
  owner_org_id    TEXT NOT NULL,
  name            TEXT NOT NULL,
  ein             TEXT,
  email           TEXT,
  phone           TEXT,
  active          INTEGER NOT NULL DEFAULT 1,
  created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS firm_members (
  id          TEXT PRIMARY KEY,
  firm_id     TEXT NOT NULL REFERENCES firms(id),
  user_id     TEXT NOT NULL,
  role        TEXT NOT NULL CHECK(role IN ('owner','admin','staff')),
  created_at  TEXT NOT NULL,
  UNIQUE(firm_id, user_id)
);

CREATE TABLE IF NOT EXISTS firm_clients (
  id                  TEXT PRIMARY KEY,
  firm_id             TEXT NOT NULL REFERENCES firms(id),
  org_id              TEXT NOT NULL,
  assigned_staff_id   TEXT,
  active              INTEGER NOT NULL DEFAULT 1,
  created_at          TEXT NOT NULL,
  UNIQUE(firm_id, org_id)
);

CREATE TABLE IF NOT EXISTS advisor_alerts (
  id          TEXT PRIMARY KEY,
  org_id      TEXT NOT NULL,
  user_id     TEXT,
  firm_id     TEXT,
  type        TEXT NOT NULL,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  action_url  TEXT,
  metadata    TEXT,   -- JSON
  read        INTEGER NOT NULL DEFAULT 0,
  read_at     TEXT,
  created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tasks (
  id           TEXT PRIMARY KEY,
  org_id       TEXT NOT NULL,
  created_by   TEXT NOT NULL,
  assignee_id  TEXT,
  type         TEXT NOT NULL DEFAULT 'manual',
  title        TEXT NOT NULL,
  description  TEXT,
  due_date     TEXT,
  status       TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','in_progress','done','cancelled')),
  completed_at TEXT,
  created_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS health_scores (
  id            TEXT PRIMARY KEY,
  org_id        TEXT NOT NULL UNIQUE,
  overall_score INTEGER NOT NULL,
  breakdown     TEXT NOT NULL,  -- JSON
  signals       TEXT NOT NULL,  -- JSON
  computed_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ai_insights (
  id             TEXT PRIMARY KEY,
  org_id         TEXT NOT NULL,
  insight        TEXT NOT NULL,
  score_snapshot TEXT,  -- JSON
  created_at     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS org_webhooks (
  id        TEXT PRIMARY KEY,
  org_id    TEXT NOT NULL,
  url       TEXT NOT NULL,
  active    INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

-- Shared users/orgs table (mirrored from auth service or seeded)
CREATE TABLE IF NOT EXISTS users (
  id         TEXT PRIMARY KEY,
  email      TEXT NOT NULL UNIQUE,
  name       TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS organizations (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  plan       TEXT NOT NULL DEFAULT 'lite',
  active     INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_alerts_org_read     ON advisor_alerts(org_id, read);
CREATE INDEX IF NOT EXISTS idx_tasks_org_status    ON tasks(org_id, status);
CREATE INDEX IF NOT EXISTS idx_firm_clients_firm   ON firm_clients(firm_id);
CREATE INDEX IF NOT EXISTS idx_firm_members_user   ON firm_members(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_insights_org     ON ai_insights(org_id, created_at DESC);
