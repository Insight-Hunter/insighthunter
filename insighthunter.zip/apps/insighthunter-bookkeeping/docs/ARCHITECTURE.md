# Architecture

- Backend: Cloudflare Workers + Durable Objects
- Frontend: Astro + React + TypeScript
- Storage: R2 + KV + Durable Objects
