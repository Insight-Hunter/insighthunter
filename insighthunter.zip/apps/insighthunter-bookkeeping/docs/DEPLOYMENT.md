# Deployment

1. `./setup-resources.sh`
2. Update wrangler.toml with KV IDs
3. `./deploy.sh`
