# Development

```bash
npm install
npm run worker:dev
npm run dev
```
