/**
 * Bizforma API client
 * All calls go to /api/* which routes to the Cloudflare Worker
 */

const BASE = '/api';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface BusinessFormData {
  concept: {
    businessIdea: string;
    targetMarket: string;
    products: string;
    uniqueValue: string;
  };
  naming: {
    businessName: string;
    alternateNames: string;
    domainAvailable: boolean;
  };
  entity: {
    type: string;
    state: string;
    owners: string;
  };
  registration: {
    registeredAgent: string;
    businessAddress: string;
    mailingAddress: string;
  };
  einTax: {
    einApplied: boolean;
    einNumber: string;
    taxElection: string;
  };
  compliance: {
    sosFilingDate: string;
    annualReportRequired: boolean;
    salesTaxPermit: boolean;
  };
  accounting: {
    software: string;
    accountant: string;
    taxStrategy: string;
  };
  financing: {
    startupCosts: string;
    fundingSources: string;
    businessAccount: string;
  };
  marketing: {
    strategy: string;
    channels: string;
    budget: string;
  };
  webDesign: {
    domainName: string;
    hosting: string;
    dnsProvider: string;
    emailSetup: string;
  };
}

export interface NameSuggestion {
  name: string;
  rationale: string;
  domainSuggestion: string;
}

export interface EntityRecommendation {
  recommended: string;
  alternatives: string[];
  reasoning: string;
  pros: string[];
  cons: string[];
  taxImplications: string;
}

export interface ComplianceEvent {
  title: string;
  category: string;
  dueDate: string;
  description: string;
  penalty?: string;
  recurring?: string;
}

// ─── Session ──────────────────────────────────────────────────────────────────

export async function createOrResumeSession(sessionId?: string) {
  const res = await fetch(`${BASE}/session`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sessionId }),
  });
  return res.json() as Promise<{ sessionId: string; data: Record<string, unknown>; resumed: boolean }>;
}

export async function saveSession(sessionId: string, data: Record<string, unknown>) {
  const res = await fetch(`${BASE}/session/${sessionId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json() as Promise<{ success: boolean }>;
}

// ─── Business ─────────────────────────────────────────────────────────────────

export async function saveBusiness(payload: {
  businessName: string;
  entityType: string;
  state: string;
  sessionId?: string;
  formData: BusinessFormData;
}) {
  const res = await fetch(`${BASE}/business`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.json() as Promise<{ success: boolean; businessId: number }>;
}

// ─── AI Features ──────────────────────────────────────────────────────────────

export async function getNameSuggestions(params: {
  businessIdea: string;
  industry: string;
  style?: string;
}): Promise<NameSuggestion[]> {
  const res = await fetch(`${BASE}/ai/name-suggestions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json()) as { success: boolean; suggestions: NameSuggestion[] };
  return data.suggestions ?? [];
}

export async function getEntityRecommendation(params: {
  businessIdea: string;
  owners: number;
  state: string;
  revenueExpected: string;
  liabilityPriority: boolean;
}): Promise<EntityRecommendation | null> {
  const res = await fetch(`${BASE}/ai/entity-recommendation`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json()) as { success: boolean; recommendation: EntityRecommendation };
  return data.recommendation ?? null;
}

export async function generateComplianceCalendar(params: {
  entityType: string;
  state: string;
  formationDate?: string;
  hasSalesTax?: boolean;
  taxElection?: string;
}): Promise<ComplianceEvent[]> {
  const res = await fetch(`${BASE}/ai/compliance-calendar`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json()) as { success: boolean; events: ComplianceEvent[] };
  return data.events ?? [];
}

/**
 * Streaming AI chat — returns an async generator of text chunks.
 */
export async function* streamChat(params: {
  message: string;
  context?: string;
  history?: Array<{ role: 'user' | 'assistant'; content: string }>;
}): AsyncGenerator<string> {
  const res = await fetch(`${BASE}/ai/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.body) return;

  const reader = res.body.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = decoder.decode(value, { stream: true });

    // Parse SSE format: data: {...}
    for (const line of chunk.split('\n')) {
      if (line.startsWith('data: ')) {
        try {
          const json = JSON.parse(line.slice(6));
          const text = (json as { response?: string })?.response ?? '';
          if (text) yield text;
        } catch {
          // Ignore parse errors for incomplete chunks
        }
      }
    }
  }
}
