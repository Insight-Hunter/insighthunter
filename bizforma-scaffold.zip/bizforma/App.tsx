import { BusinessWizard } from './components/BusinessWizard';
import './styles/globals.css';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a1a] via-[#0f0f1f] to-[#1a1a28] relative overflow-hidden">
      {/* Animated gradient mesh background */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-[128px] animate-[pulse_8s_ease-in-out_infinite]"></div>
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-[128px] animate-[pulse_10s_ease-in-out_infinite]"></div>
        <div className="absolute bottom-0 left-1/3 w-96 h-96 bg-slate-500 rounded-full mix-blend-multiply filter blur-[128px] animate-[pulse_12s_ease-in-out_infinite]"></div>
      </div>

      {/* Grid pattern overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px',
        }}
      ></div>

      <BusinessWizard />
    </div>
  );
}
