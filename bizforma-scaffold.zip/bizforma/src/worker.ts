/**
 * Bizforma — InsightHunters Business Formation Assistant
 * Cloudflare Worker: API backend with D1, KV, R2, Workers AI
 */

import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { logger } from 'hono/logger';

export interface Env {
  // Cloudflare bindings
  DB: D1Database;
  BUSINESS_DATA: KVNamespace;
  DOCUMENTS: R2Bucket;
  AI: Ai;
  ASSETS: Fetcher;

  // Secrets (set via wrangler secret put)
  ANTHROPIC_API_KEY: string;
}

const app = new Hono<{ Bindings: Env }>();

// ─── Middleware ───────────────────────────────────────────────────────────────

app.use('*', logger());
app.use(
  '/api/*',
  cors({
    origin: ['https://bizforma.insighthunters.com', 'http://localhost:3000'],
    allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'Authorization'],
  })
);

// ─── Health Check ─────────────────────────────────────────────────────────────

app.get('/api/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString(), service: 'Bizforma API' });
});

// ─── Business Session ─────────────────────────────────────────────────────────

/**
 * Create or resume a formation session.
 * Returns a sessionId used to persist wizard progress across page reloads.
 */
app.post('/api/session', async (c) => {
  try {
    const body = await c.req.json<{ sessionId?: string }>();
    const sessionId = body.sessionId ?? crypto.randomUUID();

    // Check if session already exists in KV
    const existing = await c.env.BUSINESS_DATA.get(`session:${sessionId}`, 'json');
    if (existing) {
      return c.json({ sessionId, data: existing, resumed: true });
    }

    // Initialize empty session
    const emptySession = {
      sessionId,
      currentStep: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      formData: {},
    };

    await c.env.BUSINESS_DATA.put(`session:${sessionId}`, JSON.stringify(emptySession), {
      expirationTtl: 60 * 60 * 24 * 30, // 30 days
    });

    return c.json({ sessionId, data: emptySession, resumed: false });
  } catch (err) {
    console.error('Session error:', err);
    return c.json({ error: 'Failed to create session' }, 500);
  }
});

/**
 * Save wizard progress for a session.
 */
app.put('/api/session/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const body = await c.req.json();

    const updated = {
      ...body,
      sessionId,
      updatedAt: new Date().toISOString(),
    };

    await c.env.BUSINESS_DATA.put(`session:${sessionId}`, JSON.stringify(updated), {
      expirationTtl: 60 * 60 * 24 * 30,
    });

    return c.json({ success: true, sessionId });
  } catch (err) {
    console.error('Save session error:', err);
    return c.json({ error: 'Failed to save session' }, 500);
  }
});

// ─── Business Data (D1) ───────────────────────────────────────────────────────

/**
 * Save completed business formation data to D1.
 */
app.post('/api/business', async (c) => {
  try {
    const data = await c.req.json<{
      businessName: string;
      entityType: string;
      state: string;
      sessionId?: string;
      formData: Record<string, unknown>;
    }>();

    if (!data.businessName) {
      return c.json({ error: 'businessName is required' }, 400);
    }

    // Insert into D1
    const result = await c.env.DB.prepare(
      `INSERT INTO businesses (business_name, entity_type, state, form_data, created_at, updated_at)
       VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))`
    )
      .bind(data.businessName, data.entityType ?? null, data.state ?? null, JSON.stringify(data.formData ?? {}))
      .run();

    const businessId = result.meta.last_row_id;

    // Also cache in KV for fast reads
    await c.env.BUSINESS_DATA.put(
      `business:${data.businessName.toLowerCase().replace(/\s+/g, '-')}`,
      JSON.stringify({ ...data, id: businessId }),
      { expirationTtl: 60 * 60 * 24 * 90 }
    );

    return c.json({ success: true, businessId, businessName: data.businessName });
  } catch (err) {
    console.error('Save business error:', err);
    return c.json({ error: 'Failed to save business data' }, 500);
  }
});

/**
 * Retrieve a business by name or ID.
 */
app.get('/api/business', async (c) => {
  try {
    const name = c.req.query('name');
    const id = c.req.query('id');

    if (!name && !id) {
      return c.json({ error: 'Provide name or id query parameter' }, 400);
    }

    // Try KV cache first
    if (name) {
      const cached = await c.env.BUSINESS_DATA.get(
        `business:${name.toLowerCase().replace(/\s+/g, '-')}`,
        'json'
      );
      if (cached) return c.json({ success: true, data: cached, source: 'cache' });
    }

    // Fall back to D1
    const query = id
      ? c.env.DB.prepare('SELECT * FROM businesses WHERE id = ?').bind(id)
      : c.env.DB.prepare('SELECT * FROM businesses WHERE business_name = ?').bind(name);

    const row = await query.first();
    if (!row) return c.json({ error: 'Business not found' }, 404);

    return c.json({ success: true, data: row, source: 'database' });
  } catch (err) {
    console.error('Get business error:', err);
    return c.json({ error: 'Failed to retrieve business' }, 500);
  }
});

// ─── AI Business Advisor ──────────────────────────────────────────────────────

/**
 * AI-powered business name suggestions using Workers AI (llama model).
 * Falls back to Anthropic Claude if ANTHROPIC_API_KEY is set.
 */
app.post('/api/ai/name-suggestions', async (c) => {
  try {
    const body = await c.req.json<{
      businessIdea: string;
      industry: string;
      style?: string;
    }>();

    if (!body.businessIdea) {
      return c.json({ error: 'businessIdea is required' }, 400);
    }

    const prompt = `You are a creative business naming expert. Generate 8 unique, memorable business name suggestions for the following:

Business Idea: ${body.businessIdea}
Industry: ${body.industry ?? 'general'}
Style preference: ${body.style ?? 'professional and modern'}

Return ONLY a JSON array of objects, no markdown, no explanation. Format:
[{"name": "ExampleName", "rationale": "Brief reason why this name works", "domainSuggestion": "examplename.com"}]`;

    // Use Workers AI (llama-3.1-8b-instruct)
    const response = await c.env.AI.run('@cf/meta/llama-3.1-8b-instruct', {
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 800,
    });

    const text = (response as { response: string }).response ?? '';

    // Safely parse JSON from AI response
    let suggestions: unknown[] = [];
    try {
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (jsonMatch) suggestions = JSON.parse(jsonMatch[0]);
    } catch {
      suggestions = [];
    }

    return c.json({ success: true, suggestions });
  } catch (err) {
    console.error('AI name suggestions error:', err);
    return c.json({ error: 'Failed to generate suggestions' }, 500);
  }
});

/**
 * AI-powered entity type recommendation based on business profile.
 */
app.post('/api/ai/entity-recommendation', async (c) => {
  try {
    const body = await c.req.json<{
      businessIdea: string;
      owners: number;
      state: string;
      revenueExpected: string;
      liabilityPriority: boolean;
    }>();

    const prompt = `You are a business formation attorney assistant. Recommend the best entity type for this business:

Business: ${body.businessIdea}
Number of owners: ${body.owners ?? 1}
State of formation: ${body.state ?? 'Not specified'}
Expected revenue: ${body.revenueExpected ?? 'unknown'}
Liability protection is a priority: ${body.liabilityPriority ? 'Yes' : 'No'}

Return ONLY a JSON object, no markdown. Format:
{
  "recommended": "LLC",
  "alternatives": ["S-Corp", "Sole Proprietorship"],
  "reasoning": "Brief explanation",
  "pros": ["Pro 1", "Pro 2"],
  "cons": ["Con 1"],
  "taxImplications": "Brief tax note"
}`;

    const response = await c.env.AI.run('@cf/meta/llama-3.1-8b-instruct', {
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 600,
    });

    const text = (response as { response: string }).response ?? '';
    let recommendation: unknown = {};
    try {
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) recommendation = JSON.parse(jsonMatch[0]);
    } catch {
      recommendation = { error: 'Could not parse recommendation' };
    }

    return c.json({ success: true, recommendation });
  } catch (err) {
    console.error('Entity recommendation error:', err);
    return c.json({ error: 'Failed to generate recommendation' }, 500);
  }
});

/**
 * AI-powered compliance calendar generation.
 * Returns key dates and deadlines for the business.
 */
app.post('/api/ai/compliance-calendar', async (c) => {
  try {
    const body = await c.req.json<{
      entityType: string;
      state: string;
      formationDate?: string;
      hasSalesTax?: boolean;
      taxElection?: string;
    }>();

    const prompt = `You are a business compliance expert. Generate a compliance calendar for:

Entity Type: ${body.entityType}
State: ${body.state}
Formation Date: ${body.formationDate ?? new Date().toISOString().split('T')[0]}
Sales Tax Required: ${body.hasSalesTax ? 'Yes' : 'No'}
Tax Election: ${body.taxElection ?? 'Default'}

Return ONLY a JSON array of compliance events, no markdown. Format:
[{
  "title": "Annual Report Due",
  "category": "state_filing",
  "dueDate": "2025-04-01",
  "description": "File annual report with Secretary of State",
  "penalty": "$50 late fee",
  "recurring": "annual"
}]

Include: annual reports, tax filing deadlines, sales tax remittances, BOI report, estimated taxes.`;

    const response = await c.env.AI.run('@cf/meta/llama-3.1-8b-instruct', {
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 1200,
    });

    const text = (response as { response: string }).response ?? '';
    let events: unknown[] = [];
    try {
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (jsonMatch) events = JSON.parse(jsonMatch[0]);
    } catch {
      events = [];
    }

    return c.json({ success: true, events });
  } catch (err) {
    console.error('Compliance calendar error:', err);
    return c.json({ error: 'Failed to generate compliance calendar' }, 500);
  }
});

/**
 * AI chat assistant — general business formation Q&A.
 * Streaming response using Workers AI.
 */
app.post('/api/ai/chat', async (c) => {
  try {
    const body = await c.req.json<{
      message: string;
      context?: string; // current wizard step context
      history?: Array<{ role: 'user' | 'assistant'; content: string }>;
    }>();

    if (!body.message) {
      return c.json({ error: 'message is required' }, 400);
    }

    const systemPrompt = `You are Bizforma, an AI business formation assistant from InsightHunters.
You help entrepreneurs form businesses correctly and efficiently.
Current context: ${body.context ?? 'General business formation guidance'}
Be concise, practical, and encouraging. Always note you are not a licensed attorney.`;

    const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
      { role: 'system', content: systemPrompt },
      ...(body.history ?? []),
      { role: 'user', content: body.message },
    ];

    // Stream the response
    const stream = await c.env.AI.run('@cf/meta/llama-3.1-8b-instruct', {
      messages,
      max_tokens: 512,
      stream: true,
    });

    return new Response(stream as ReadableStream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    });
  } catch (err) {
    console.error('AI chat error:', err);
    return c.json({ error: 'AI chat failed' }, 500);
  }
});

// ─── Document Storage (R2) ────────────────────────────────────────────────────

/**
 * Upload a formation document (Articles of Organization, EIN letter, etc.)
 */
app.post('/api/documents/:businessId', async (c) => {
  try {
    const businessId = c.req.param('businessId');
    const contentType = c.req.header('content-type') ?? 'application/octet-stream';
    const filename = c.req.query('filename') ?? `doc-${Date.now()}`;
    const docType = c.req.query('type') ?? 'general';

    const body = await c.req.arrayBuffer();
    const key = `businesses/${businessId}/${docType}/${filename}`;

    await c.env.DOCUMENTS.put(key, body, {
      httpMetadata: { contentType },
      customMetadata: { businessId, docType, uploadedAt: new Date().toISOString() },
    });

    // Record metadata in D1
    await c.env.DB.prepare(
      `INSERT INTO documents (business_id, document_type, document_name, file_path, file_size, uploaded_at)
       VALUES (?, ?, ?, ?, ?, datetime('now'))`
    )
      .bind(businessId, docType, filename, key, body.byteLength)
      .run();

    return c.json({ success: true, key, filename });
  } catch (err) {
    console.error('Document upload error:', err);
    return c.json({ error: 'Failed to upload document' }, 500);
  }
});

/**
 * Get a presigned-style URL to download a document.
 */
app.get('/api/documents/:businessId/:filename', async (c) => {
  try {
    const businessId = c.req.param('businessId');
    const filename = c.req.param('filename');
    const docType = c.req.query('type') ?? 'general';
    const key = `businesses/${businessId}/${docType}/${filename}`;

    const object = await c.env.DOCUMENTS.get(key);
    if (!object) return c.json({ error: 'Document not found' }, 404);

    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('Content-Disposition', `attachment; filename="${filename}"`);
    headers.set('etag', object.httpEtag);

    return new Response(object.body, { headers });
  } catch (err) {
    console.error('Document download error:', err);
    return c.json({ error: 'Failed to retrieve document' }, 500);
  }
});

// ─── Compliance Events (D1) ───────────────────────────────────────────────────

app.get('/api/compliance/:businessId', async (c) => {
  try {
    const businessId = c.req.param('businessId');
    const results = await c.env.DB.prepare(
      'SELECT * FROM compliance_events WHERE business_id = ? ORDER BY event_date ASC'
    )
      .bind(businessId)
      .all();

    return c.json({ success: true, events: results.results });
  } catch (err) {
    console.error('Compliance fetch error:', err);
    return c.json({ error: 'Failed to fetch compliance events' }, 500);
  }
});

app.post('/api/compliance/:businessId', async (c) => {
  try {
    const businessId = c.req.param('businessId');
    const event = await c.req.json<{
      eventType: string;
      eventName: string;
      eventDate: string;
      description?: string;
      reminderDays?: number;
    }>();

    await c.env.DB.prepare(
      `INSERT INTO compliance_events (business_id, event_type, event_name, event_date, description, reminder_days)
       VALUES (?, ?, ?, ?, ?, ?)`
    )
      .bind(
        businessId,
        event.eventType,
        event.eventName,
        event.eventDate,
        event.description ?? null,
        event.reminderDays ?? 30
      )
      .run();

    return c.json({ success: true });
  } catch (err) {
    console.error('Compliance save error:', err);
    return c.json({ error: 'Failed to save compliance event' }, 500);
  }
});

// ─── Static Assets (SPA fallback) ─────────────────────────────────────────────

app.get('*', (c) => {
  return c.env.ASSETS.fetch(c.req.raw);
});

export default app;
