export const entityAdvisorServiceTest = "placeholder";
