export const stateServiceTest = "placeholder";
