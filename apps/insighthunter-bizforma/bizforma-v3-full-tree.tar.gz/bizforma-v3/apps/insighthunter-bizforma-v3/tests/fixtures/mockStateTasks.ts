export const mockStateTasks = ["File annual report", "Renew business license"];
