export const mockFormationCase = { id: "case_1", businessId: "biz_1", status: "draft" };
