export const mockPayroll = { employeeName: "Jane Doe", amountCents: 120000 };
