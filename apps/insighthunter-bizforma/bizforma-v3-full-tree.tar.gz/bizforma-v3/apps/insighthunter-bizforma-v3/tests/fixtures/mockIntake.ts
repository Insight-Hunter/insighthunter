export const mockIntake = { concept: "AI bookkeeping", businessName: "Insight Hunter Biz", entityType: "LLC", stateCode: "GA" };
