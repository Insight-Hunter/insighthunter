export interface GlasscomponentsProps { title?: string; description?: string; }
export default function Glasscomponents(_props: GlasscomponentsProps) { return null; }
