export interface LegoformshubProps { title?: string; description?: string; }
export default function Legoformshub(_props: LegoformshubProps) { return null; }
