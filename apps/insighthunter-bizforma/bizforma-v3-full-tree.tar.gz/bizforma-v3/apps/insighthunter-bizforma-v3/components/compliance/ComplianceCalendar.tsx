export interface CompliancecalendarProps { title?: string; description?: string; }
export default function Compliancecalendar(_props: CompliancecalendarProps) { return null; }
