export interface CompliancedashboardProps { title?: string; description?: string; }
export default function Compliancedashboard(_props: CompliancedashboardProps) { return null; }
