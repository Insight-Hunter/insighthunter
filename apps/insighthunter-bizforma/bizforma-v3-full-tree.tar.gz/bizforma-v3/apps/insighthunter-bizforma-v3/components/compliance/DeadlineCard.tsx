export interface DeadlinecardProps { title?: string; description?: string; }
export default function Deadlinecard(_props: DeadlinecardProps) { return null; }
