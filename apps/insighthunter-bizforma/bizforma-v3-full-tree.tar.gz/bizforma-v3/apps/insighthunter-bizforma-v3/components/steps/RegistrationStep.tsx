export interface RegistrationstepProps { title?: string; description?: string; }
export default function Registrationstep(_props: RegistrationstepProps) { return null; }
