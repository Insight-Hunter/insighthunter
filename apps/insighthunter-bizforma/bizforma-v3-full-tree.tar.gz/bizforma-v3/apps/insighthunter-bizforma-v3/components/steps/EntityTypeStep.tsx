export interface EntitytypestepProps { title?: string; description?: string; }
export default function Entitytypestep(_props: EntitytypestepProps) { return null; }
