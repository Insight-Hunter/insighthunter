export interface ConceptstepProps { title?: string; description?: string; }
export default function Conceptstep(_props: ConceptstepProps) { return null; }
