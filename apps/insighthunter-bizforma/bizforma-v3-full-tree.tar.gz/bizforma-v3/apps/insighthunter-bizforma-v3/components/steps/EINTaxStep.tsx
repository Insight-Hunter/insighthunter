export interface EintaxstepProps { title?: string; description?: string; }
export default function Eintaxstep(_props: EintaxstepProps) { return null; }
