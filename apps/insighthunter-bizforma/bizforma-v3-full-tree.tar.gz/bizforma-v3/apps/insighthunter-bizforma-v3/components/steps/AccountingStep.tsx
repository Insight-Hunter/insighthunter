export interface AccountingstepProps { title?: string; description?: string; }
export default function Accountingstep(_props: AccountingstepProps) { return null; }
