export interface FinancingstepProps { title?: string; description?: string; }
export default function Financingstep(_props: FinancingstepProps) { return null; }
