export interface ScorpelectionProps { title?: string; description?: string; }
export default function Scorpelection(_props: ScorpelectionProps) { return null; }
