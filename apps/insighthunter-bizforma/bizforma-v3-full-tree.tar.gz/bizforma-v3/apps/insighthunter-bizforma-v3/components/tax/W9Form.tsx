export interface W9formProps { title?: string; description?: string; }
export default function W9form(_props: W9formProps) { return null; }
