export interface ImagewithfallbackProps { title?: string; description?: string; }
export default function Imagewithfallback(_props: ImagewithfallbackProps) { return null; }
