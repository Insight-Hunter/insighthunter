export interface PayrollhubProps { title?: string; description?: string; }
export default function Payrollhub(_props: PayrollhubProps) { return null; }
