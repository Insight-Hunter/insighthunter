export interface Form1099Props { title?: string; description?: string; }
export default function Form1099(_props: Form1099Props) { return null; }
