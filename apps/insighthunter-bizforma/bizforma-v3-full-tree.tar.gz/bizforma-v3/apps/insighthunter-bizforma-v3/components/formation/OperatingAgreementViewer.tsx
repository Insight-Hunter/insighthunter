export interface OperatingagreementviewerProps { title?: string; description?: string; }
export default function Operatingagreementviewer(_props: OperatingagreementviewerProps) { return null; }
