export interface EinguideProps { title?: string; description?: string; }
export default function Einguide(_props: EinguideProps) { return null; }
