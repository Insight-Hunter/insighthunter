export interface FormationsummaryProps { title?: string; description?: string; }
export default function Formationsummary(_props: FormationsummaryProps) { return null; }
