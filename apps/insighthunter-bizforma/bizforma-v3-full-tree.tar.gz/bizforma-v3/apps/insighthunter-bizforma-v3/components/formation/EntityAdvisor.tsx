export interface EntityadvisorProps { title?: string; description?: string; }
export default function Entityadvisor(_props: EntityadvisorProps) { return null; }
