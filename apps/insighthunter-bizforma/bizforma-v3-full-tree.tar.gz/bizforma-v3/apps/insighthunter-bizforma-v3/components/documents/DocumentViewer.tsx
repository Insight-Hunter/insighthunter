export interface DocumentviewerProps { title?: string; description?: string; }
export default function Documentviewer(_props: DocumentviewerProps) { return null; }
