export interface ProgressstepperProps { title?: string; description?: string; }
export default function Progressstepper(_props: ProgressstepperProps) { return null; }
