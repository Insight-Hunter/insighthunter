export interface BusinesswizardProps { title?: string; description?: string; }
export default function Businesswizard(_props: BusinesswizardProps) { return null; }
