export interface SkeletonProps { title?: string; description?: string; }
export default function Skeleton(_props: SkeletonProps) { return null; }
