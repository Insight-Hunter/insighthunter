export interface ProgressProps { title?: string; description?: string; }
export default function Progress(_props: ProgressProps) { return null; }
