export interface BadgeProps { title?: string; description?: string; }
export default function Badge(_props: BadgeProps) { return null; }
