export interface CardProps { title?: string; description?: string; }
export default function Card(_props: CardProps) { return null; }
