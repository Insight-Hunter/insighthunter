export interface DialogProps { title?: string; description?: string; }
export default function Dialog(_props: DialogProps) { return null; }
