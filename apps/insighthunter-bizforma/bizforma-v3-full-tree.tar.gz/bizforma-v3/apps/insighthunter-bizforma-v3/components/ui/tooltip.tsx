export interface TooltipProps { title?: string; description?: string; }
export default function Tooltip(_props: TooltipProps) { return null; }
