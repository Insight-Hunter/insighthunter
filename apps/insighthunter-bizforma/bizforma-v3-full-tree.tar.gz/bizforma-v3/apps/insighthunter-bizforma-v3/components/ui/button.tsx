export interface ButtonProps { title?: string; description?: string; }
export default function Button(_props: ButtonProps) { return null; }
