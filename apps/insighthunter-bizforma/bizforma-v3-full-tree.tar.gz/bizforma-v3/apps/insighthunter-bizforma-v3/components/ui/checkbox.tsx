export interface CheckboxProps { title?: string; description?: string; }
export default function Checkbox(_props: CheckboxProps) { return null; }
