export interface AccordionProps { title?: string; description?: string; }
export default function Accordion(_props: AccordionProps) { return null; }
