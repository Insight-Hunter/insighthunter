export interface SeparatorProps { title?: string; description?: string; }
export default function Separator(_props: SeparatorProps) { return null; }
