export interface TabsProps { title?: string; description?: string; }
export default function Tabs(_props: TabsProps) { return null; }
