export interface LabelProps { title?: string; description?: string; }
export default function Label(_props: LabelProps) { return null; }
