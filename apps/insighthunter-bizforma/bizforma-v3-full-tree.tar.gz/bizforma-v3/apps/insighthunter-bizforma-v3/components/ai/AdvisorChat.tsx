export interface AdvisorchatProps { title?: string; description?: string; }
export default function Advisorchat(_props: AdvisorchatProps) { return null; }
