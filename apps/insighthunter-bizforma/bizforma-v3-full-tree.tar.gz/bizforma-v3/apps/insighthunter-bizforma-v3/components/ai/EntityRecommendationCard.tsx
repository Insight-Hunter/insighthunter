export interface EntityrecommendationcardProps { title?: string; description?: string; }
export default function Entityrecommendationcard(_props: EntityrecommendationcardProps) { return null; }
