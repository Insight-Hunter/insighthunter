export function buildSS4Prefill(payload: Record<string, unknown>) { return { form: "SS-4", payload, guidance: "Review responsible party and tax classification before filing." }; }
