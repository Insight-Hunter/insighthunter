import { taxAccountChecklist } from "../data/taxAccountChecklist"; export function getTaxTasks() { return taxAccountChecklist.default; }
