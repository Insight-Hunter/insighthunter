export async function renderPdfPlaceholder(html: string) { return new TextEncoder().encode(html); }
