import { states } from "../data/states"; export function getStateRequirements(stateCode: string) { return states.find((s) => s.stateCode === stateCode) ?? null; }
