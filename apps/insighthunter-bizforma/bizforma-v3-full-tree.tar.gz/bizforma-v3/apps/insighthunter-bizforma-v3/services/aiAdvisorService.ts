export async function askAdvisor(env: any, message: string) { return env.AI.run("@cf/meta/llama-3.1-8b-instruct", { prompt: message }); }
