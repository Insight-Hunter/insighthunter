export function renderFields(fields: Array<{ label: string; type: string }>) { return fields.map((f) => `${f.label} (${f.type})`); }
