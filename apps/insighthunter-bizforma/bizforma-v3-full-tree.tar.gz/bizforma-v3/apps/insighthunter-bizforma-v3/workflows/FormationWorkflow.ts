export class FormationWorkflow { async run(input: Record<string, unknown>) { return { status: "queued", input }; } }
