export class ComplianceWorkflow { async run(input: Record<string, unknown>) { return { status: "queued", input }; } }
