# BizForma v3
Expanded app tree matching the requested BizForma structure, wired for Cloudflare Workers and centralized auth at auth.insighthunter.app.
