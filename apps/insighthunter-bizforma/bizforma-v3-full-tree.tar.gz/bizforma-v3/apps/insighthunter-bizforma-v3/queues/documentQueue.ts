export default { async queue(batch: MessageBatch<any>) { for (const msg of batch.messages) { console.log("document queue", msg.body); msg.ack(); } } };
