export default { async queue(batch: MessageBatch<any>) { for (const msg of batch.messages) { console.log("reminder queue", msg.body); msg.ack(); } } };
