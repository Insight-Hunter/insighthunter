export interface W4Record { id: string; employeeName: string; payload: Record<string, unknown>; }
export interface Contractor1099 { id: string; contractorName: string; amountCents: number; taxYear: number; }
export interface PayrollSetup { id: string; stateCode: string; tasks: string[]; }
