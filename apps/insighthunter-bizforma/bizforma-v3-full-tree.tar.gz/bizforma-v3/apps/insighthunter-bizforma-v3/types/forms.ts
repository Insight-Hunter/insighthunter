export interface LegoFormField { id: string; label: string; type: string; required?: boolean; }
export interface LegoForm { id: string; name: string; fields: LegoFormField[]; }
export interface FormTemplate extends LegoForm {}
export interface FormSubmission { id: string; templateId: string; values: Record<string, unknown>; }
