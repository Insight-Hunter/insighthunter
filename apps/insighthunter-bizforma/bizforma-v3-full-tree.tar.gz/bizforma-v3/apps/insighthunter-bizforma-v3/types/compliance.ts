export interface ComplianceEvent { id: string; title: string; dueAt: string; category: string; status: string; }
export interface RenewalSchedule { id: string; title: string; frequency: string; nextDueAt: string; }
