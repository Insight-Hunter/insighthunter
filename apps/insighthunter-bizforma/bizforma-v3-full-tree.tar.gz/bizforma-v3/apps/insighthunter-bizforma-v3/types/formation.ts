export interface IntakeAnswers { concept: string; businessName: string; entityType: string; stateCode: string; needsPayroll?: boolean; }
export interface EntityRec { entityType: string; score: number; rationale: string; }
export interface FormationCase { id: string; businessId: string; status: string; intake: IntakeAnswers; }
