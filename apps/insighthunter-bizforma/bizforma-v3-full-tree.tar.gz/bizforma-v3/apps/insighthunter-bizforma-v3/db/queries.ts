import type { Env } from "../types/env"; export async function listRows(env: Env, table: string) { return env.DB.prepare(`SELECT * FROM ${table}`).all(); }
