export function log(level: "info"|"warn"|"error", message: string, extra?: unknown) { console[level](`[bizforma] ${message}`, extra ?? ""); }
