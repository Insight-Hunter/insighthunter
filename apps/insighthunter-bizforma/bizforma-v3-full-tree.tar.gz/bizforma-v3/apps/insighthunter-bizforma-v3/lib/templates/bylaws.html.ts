export const template = (title: string, body: string) => `<!doctype html><html><body><h1>${title}</h1><div>${body}</div></body></html>`;
