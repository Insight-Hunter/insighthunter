export const entityMatrix = { LLC: 85, "S-Corp": 78, "C-Corp": 72, SoleProprietorship: 50 };
