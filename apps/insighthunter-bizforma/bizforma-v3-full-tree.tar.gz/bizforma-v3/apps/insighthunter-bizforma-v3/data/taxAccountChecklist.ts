export const taxAccountChecklist = { default: ["Apply for EIN", "Create IRS online account", "Register state withholding account", "Review sales tax nexus"] };
